brew install git-secrets
brew install gitleaks
